package forum;

public class CommentRequest {
	private int titleid;

	public int getTitleid() {
		return titleid;
	}

	public void setTitleid(int titleid) {
		this.titleid = titleid;
	}
	
}
